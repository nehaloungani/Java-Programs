import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class IOBank {
    File myRec;
    private String[] userNames;
    private String[] password;
    private float[] amounts;
    int recordCount = 0;
    public static void main(String[] args) {
      IOBank checkobj = new IOBank("myRec0.csv");
     checkobj.addAccount("Saleem", "bozdar", 300.0f);
       System.out.println(Arrays.toString(checkobj.getAmounts()));
       System.out.println(Arrays.toString(checkobj.getPassword()));
       System.out.println(Arrays.toString(checkobj.getUserNames()));
}
public IOBank(String fileName){
    this.myRec = new File(fileName);
    this.initArrays();
}
private void initArrays(){
    int count = 0;
    try {
        Scanner s = new Scanner(this.myRec);
        s.useDelimiter("[\n]");
        while (s.hasNext()) {
            s.next();
            count++;
        }
    } catch (Exception e) {
        e.printStackTrace();
        //TODO: handle exception
    }
    if(count == 0){
        System.out.println("No Records Found");
    }
    else if (this.userNames == null) {
        this.userNames = new String[count];
        this.password = new String[count];
        this.amounts = new float[count];
        this.readAccount();    
    }
    else {
        String[] tempUserNames = new String[count];
        String[] tempPassword = new String[count];
        float[] tempAmount = new float[count];
        System.arraycopy(this.userNames, 0, tempUserNames, 0, this.userNames.length);
        System.arraycopy(this.password, 0, tempPassword, 0, this.password.length);
        System.arraycopy(this.amounts, 0, tempAmount, 0, this.amounts.length);
        this.userNames = tempUserNames;
        this.password = tempPassword;
        this.amounts = tempAmount;
    }
    this.recordCount = count;
}
public String[] getUserNames(){
    return userNames;
}
public void setUserNames(String[] userNames){
    this.userNames = userNames;
}
public String[] getPassword(){
    return password;
}
public void setPassword(String[] password){
    this.password = password;
}
public float[] getAmounts(){
    return amounts;
}
public void setAmounts(float[] amounts){
    this.amounts = amounts;
}
public void addAccount(String userName, String password, float amount){
    try {
        FileWriter fw = new FileWriter(this.myRec, true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        // amount,password,userName
        pw.println(amount+","+password+","+userName);
        pw.flush();
        pw.close();
        this.initArrays();
    } catch (Exception e) {
        e.printStackTrace();
        //TODO: handle exception
    }
}
    public void readAccount() {
        try {
            FileReader fr = new FileReader(this.myRec);
            BufferedReader br = new BufferedReader(fr);
            String line;
            int i = 0;
            while ((line = br.readLine()) != null) {
                String[] a = line.split(",");
                this.amounts[i] = Float.parseFloat(a[0]);
                this.password[i] = a[1];
                this.userNames[i] = a[2];
                i++;   
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
            //TODO: handle exception
        }
}
}