import java.util.Scanner;
interface MyMenu{
    //abstract static void createAccount();
    void createAccount();
    void showAccount();
    void addAmount();
    void withdrawAmount();
    void changePassword();
    void exitProgram();
}
class Account{
    private String userName;
    private String password;
    private double amount;
    public Account(String userName, String password, double amount){
        this.userName = userName;
        this.password = password;
        this.amount = amount;
    }
    public String getuserName(){
        return this.userName;
    } 
    public String getpassword(){
        return this.password;
    } 
    public double getamount(){
        return this.amount;
    } 
    public void deposiAmount(double amount){
        //System.out.print("your current amount is " + this.amount);
        System.out.println("Dear " + this.userName + " your current amount is " + this.amount);
        this.amount += amount;
        System.out.println("and after deposit: " + this.amount);
    }
    public void withdrawAmount(double amount){
        System.out.println("Dear " + this.userName + " your current amount is " + this.amount);
        this.amount -= amount;
        System.out.println("and after withdraw: " + this.amount);
    }
    public void setPassword(String password){
        if(this.password.equals(password)){
            this.password = password;
        }else{
            System.out.println("Invaild previous password.");
        }
    }
}
class MyBank implements MyMenu{
    private Account[] users = new Account[10];
    private int regUsers = 0;
    Scanner inp = new Scanner(System.in);
    public void createAccount(){
        System.out.print("Enter username:");
        String userName = inp.nextLine();
        System.out.print("Enter password:");
        String password = inp.nextLine(); 
        System.out.print("Enter amount:");
        double amount = inp.nextDouble();
        inp.nextLine();
        Account temp = new Account(userName, password, amount);
        users[regUsers++] = temp;
        System.out.println("User registered.");        
    }
    public void showAccount(){
        for(int i = 0; i < regUsers; i++){
            System.out.println("User " + (((int)i)  + 1) +", Name: " + users[i].getuserName());
        }
    }
    public void addAmount(){
        this.showAccount();
        System.out.println("Enter your id:");
        int id = inp.nextInt();
        System.out.println("Enter amount:");
        double amount = inp.nextDouble();
        inp.nextLine();
        users[id-1].deposiAmount(amount);
    }
    public void withdrawAmount(){
        this.showAccount();
        System.out.println("Enter your id:");
        int id = inp.nextInt();
        System.out.println("Enter amount:");
        double amount = inp.nextDouble();
        inp.nextLine();
        users[id-1].withdrawAmount(amount);
    }
    public void inquireAmount() {
        this.showAccount();
        System.out.println("Enter your id:");
        int id = inp.nextInt();
        System.out.println("Dear " + users[id-1].getuserName() + " your amount is " + users[id-1].getamount());
    }
    public void changePassword(){
    }
    public void exitProgram(){

    }
}
    public class Main{
    public static void greetUser() {
        System.out.println("======================================================================");
        System.out.println("N: Create new account");
        System.out.println("S: Show account");
        System.out.println("W: Withdraw amount");
        System.out.println("D: Deposit amount");
        System.out.println("A: Inquire amount");
        System.out.println("P: Change password");
        System.out.println("E: Exit program");
        System.out.println("======================================================================");
    }
    public static void main(String[] args) {
        char key = '\0';
        Scanner inp = new Scanner(System.in);
        MyBank bank = new MyBank();
        while(key != 'E'){
            greetUser();
            System.out.print("Enter your choice:");
            key =inp.next().charAt(0);
            switch (key){
                case 'N':
                bank.createAccount();
                break;
                case 'S':
                bank.showAccount();
                break;
                case 'W':
                bank.withdrawAmount();
                break;
                case 'A':
                bank.inquireAmount();
                break;
                case 'D':
                bank.addAmount();
                break;
                case 'P':
                bank.changePassword();
                break;
                case 'E':
                System.out.println("Thank you for visiting");
                System.exit(0);
                break;
                default:
                System.out.println("Invalid choice; please try again");
                break;
            }
        }
                inp.close();
            }
        }