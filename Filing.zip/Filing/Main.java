import java.io.File; //Create a file - file handler
import java.io.FileWriter; // Write to file
import java.io.BufferedWriter; // Append to file
import java.io.IOException; // To handle
import java.io.FileNotFoundException;
import java.util.Scanner; // read 
public class Main {
    static File createFile() {
        File myObj = new File("filename.txt");
        try {
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return myObj;
    }
    static void readFile() {
        try {
            File myObj = new File("filename.txt");
            Scanner myReader = new Scanner(myObj);
            // while (myReader.hasNextLine()) {
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    static void writeFile() {
        try {
            FileWriter myWriter = new FileWriter("filename.txt");
            myWriter.write("Files in Java might be tricky, but it is fun enough!");
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    static void appendFile()  {
        try {
            String data = "Tutorials Point is a best website in the world";
            File f1 = new File("filename.txt");
            if(!f1.exists()) {
               f1.createNewFile();
            }
            FileWriter fileWritter = new FileWriter(f1.getName(),true);
            BufferedWriter bw = new BufferedWriter(fileWritter);
            bw.write('\n'+data);
            bw.close();
            System.out.println("Done");
         } catch(IOException e){
            e.printStackTrace();
         }
      }
    public static void main(String[] args) {
        createFile();
        writeFile();
        appendFile();
        readFile();
    }
}