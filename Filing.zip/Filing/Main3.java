import java.io.PrintWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;
import java.util.Scanner;
class IO{
    File myFile;
    public IO(String fileName) throws IOException {
        this.myFile = new File(fileName);
        if(this.myFile.createNewFile()){
            System.out.println("File Created");
        }else{
            System.out.println("File Already Created");
        }
    }
    public void addRecord(String name, int count, char gender, float weight) {
        try{
            FileWriter fw = new FileWriter(this.myFile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.println(name+","+count+","+gender+","+weight);
            pw.flush();
            pw.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void readRecord() {
        try{
            Scanner s = new Scanner(this.myFile);
            s.useDelimiter("[,\n]");
            while(s.hasNext()){
                String name = s.next();
                String count = s.next();
                char gender = s.next().charAt(0);
                String weight = s.next();
                System.out.println(name + ", " + count + ", " + gender + " , " + weight);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
public class Main3 {
    public static void main(String[] args) throws IOException {
        IO obj = new IO("LiveDemo.csv");
//        String name = "Mango";
//        int count = 123;
//        char gender = 'M';
//        float weight = 100.23f;
//
//        obj.addRecord(name, count, gender,weight);
//        obj.addRecord("Apple", 235, 'F',125.25f);
//            obj.addRecord("Banana", 335, 'N',105.50f);
            obj.readRecord();
    }
}