package MyArray;
public class Array2D {
    public void print_array(){
        int[][] My2D = {{1, 2, 3},
                        {4, 5, 6},       
                        {7, 8, 9}};
        System.out.println();
        for(int r = 0; r < My2D.length; r++){
            for(int c = 0; c < My2D[0].length; c++){
            System.out.println("Row["+r+"]["+c+"] = " + My2D[r][c]);
        }
    }
    }
}
