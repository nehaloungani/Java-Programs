package MyArray;
public class Array1D{
    public void print_array(){
        int[] MyArr = new int[5];
        MyArr[0] = 10;
        MyArr[1] = 20;
        MyArr[2] = 30;
        MyArr[3] = 40;
        MyArr[4] = 50;

        for(int i : MyArr){
            System.out.println(i);
        }
    }
}