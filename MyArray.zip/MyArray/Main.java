import MyArray.*;
public class Main {
    public static void main(String[] args) {
        Array1D obj = new Array1D();
        obj.print_array();
        Array2D obj1 = new Array2D();
        obj1.print_array();

    }
}
